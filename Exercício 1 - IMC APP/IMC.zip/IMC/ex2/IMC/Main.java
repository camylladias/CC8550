
//JFrame classe respons�vel por exibir a janela
import javax.swing.JFrame;

//Main - Nome da classe
public class Main {
   // Comando principal para execu��o do programa
   public static void main(String[] args) {

      Ex2 ex = new Ex2();

      ex.setLocation(400, 200);

      ex.setVisible(true);
   }
}